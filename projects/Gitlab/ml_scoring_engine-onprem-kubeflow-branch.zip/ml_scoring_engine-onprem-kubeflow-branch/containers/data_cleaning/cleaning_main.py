# import relevant packages
from parallel_pandas import ParallelPandas
import pandas as pd
from pyspark.sql.session import SparkSession
from pyspark.sql.functions import col, initcap, regexp_extract, when, datediff, round as pyround, length, lower, regexp_replace
from pyspark.sql.types import StringType, StructType, StructField
import udfs
import fire
import warnings
warnings.filterwarnings('ignore')

def main(raw_folder_path:str,
         cleaned_folder_path:str,
         tbl_dt:str):
    
    # configure the Spark session
    spark = SparkSession.builder \
    .master('local[*]') \
    .config("spark.driver.memory", "32g") \
    .appName('DigitalLending') \
    .getOrCreate()

    # initiate parallel pandas session
    ParallelPandas.initialize(n_cpu=-1, split_factor=4, disable_pr_bar=True)

    # read customers, vendors, attributes and weights data
    df_customers = spark.read.parquet(f'{raw_folder_path}/customers/*.parquet')
    df_vendors = spark.read.csv(f'{raw_folder_path}/lookup/vendors/*.csv', header=True).toPandas()
    df_string_attributes = spark.read.csv(f'{raw_folder_path}/lookup/string_attributes/*.csv', header=True).toPandas()
    df_numeric_attributes = spark.read.csv(f'{raw_folder_path}/lookup/numeric_attributes/*.csv', header=True).toPandas()
    df_weights = spark.read.csv(f'{raw_folder_path}/lookup/weights/*.csv', header=True).toPandas()
    print('Data loaded successfully')
    
    # persist customers table in cache
    df_customers.cache();

    # drop duplicates from customers table
    df_customers = df_customers.dropDuplicates()
    print('Duplicates removed')

    # rewrite column headers for customers, vendors, and weights dataframes
    pydataframe_array = [df_customers] 
    pddataframe_array = [df_string_attributes, df_numeric_attributes, df_weights, df_vendors]
    pydataframe_array = udfs.proper_columns(pydataframe_array)
    pddataframe_array = udfs.pd_proper_columns(pddataframe_array);

    # also rewrite attributes in the attribute column of the weights table in snake case
    df_weights['attribute'] = df_weights['attribute'].str.replace(' ','_').str.lower()
    print('Columns and attribute fields converted to snake case')

    # list the unique attributes in the weights, strings, and numerics table
    attribute_names = list(df_weights.attribute.unique())
    string_attributes = list(df_string_attributes.attribute.unique())
    numeric_attributes = list(df_numeric_attributes.attribute.unique())

    # create an empty dictionary to store the list of attribute dataframes
    attr_dict = {}

    # iteratively create a list of all dataframes using the sheet indices from the tables workbook
    for attr in attribute_names:
        dataframe = pd.DataFrame()
        if attr in string_attributes: dataframe = df_string_attributes[df_string_attributes['attribute']==attr].drop(['attribute','datekey'],axis=1)
        elif attr in numeric_attributes: 
            dataframe = df_numeric_attributes[df_numeric_attributes['attribute']==attr].drop(['attribute','datekey'],axis=1)
            dataframe['min_value'] = dataframe['min_value'].astype(float)
            dataframe['max_value'] = dataframe['max_value'].astype(float)
        dataframe.rename(columns={'score':attr+'_score','value':attr,'min_value':'min_'+attr,'max_value':'max_'+attr}, inplace=True)
        udfs.pd_proper_columns([dataframe])
        for column in list(dataframe.columns):
            if (dataframe[column].dtype) == 'O':
                dataframe[column] =dataframe[column].str.title()
                dataframe['vendor_code'] = dataframe['vendor_code'].str.upper()
            else: pass
        attr_dict[attr] = spark.createDataFrame(dataframe)
    print('Attribute tables created')

    # Fill null values in string columns with blanks and in numerical columns with zero and cast to integer
    string_columns = [column for column, dtype in df_customers.dtypes if dtype == 'string']
    numerical_columns = [column for column, dtype in df_customers.dtypes if dtype in ['int', 'bigint', 'float', 'double']]
    df_customers = df_customers.fillna('', subset=string_columns).fillna(0, subset=numerical_columns)
    print('Nulls filled')

    for column in numerical_columns:
        df_customers = df_customers.withColumn(column, col(column).cast("integer"))
    print('Numeric fields converted to integers')

    # make values proper case
    for column in string_columns:
        if column != "msisdn_key":
            df_customers = df_customers.withColumn(column, initcap(col(column)))
        else: pass
    print('String field values written in proper case')    

    # list all date columns
    date_columns_list = []
    for column in df_customers.columns:
        if column.endswith('dt') or column.endswith('date'):
            date_columns_list.append(column)

    # convert date columns to datetype
    df_customers = udfs.convert_date_columns(df_customers, date_columns_list)

    #  Subtract date columns from `tbl_dt` field to find number of days difference
    # convert data consumption rate mly and wly to gb and dly to mb
    # rename columns
    # rename values in marital status, employment status and line type fields
    # extract device os version
    df_customers = df_customers.withColumn(
        "last_recharge_dt",
        pyround((datediff(df_customers.tbl_dt, df_customers.last_recharge_dt) / 7)).cast('integer')
    ).withColumn(
        "last_rge_date",
        pyround(datediff(df_customers.tbl_dt, df_customers.last_rge_date)).cast('integer')
    ).withColumn(
        "last_xtratime_or_byte_sub_date",
        pyround(datediff(df_customers.tbl_dt, df_customers.last_xtratime_or_byte_sub_date)).cast('integer')
    ).withColumn(
        'last_rchg_type',
        when(col('last_rchg_type') == 'Vtu Dump', 'Vtu').otherwise(col('last_rchg_type'))
    ).withColumn('os_version', regexp_extract(df_customers['os_version'], r'(\d+)', 1))\
    .withColumn('data_consumption_rate_mly', pyround(col('data_consumption_rate_mly')/1000000).cast('integer'))\
    .withColumn('data_consumption_rate_wly', pyround(col('data_consumption_rate_wly')/1000000).cast('integer'))\
    .withColumn('data_consumption_rate_dly', pyround(col('data_consumption_rate_dly')/1000).cast('integer'))\
    .withColumnRenamed('msisdn_key', 'msisdn').withColumnRenamed('ngstate', 'state_of_residency')\
    .withColumnRenamed('os_name','device_type').withColumnRenamed('subscriber_type','line_type').withColumnRenamed('os_version','device_os_version')\
    .withColumnRenamed('bal_avg_daily','avg_dly_airtime_bal').withColumnRenamed('last_recharge_dt','date_last_topup')\
    .withColumnRenamed('last_rge_date','last_rev_gen_event_date')\
    .withColumnRenamed('nr_maritalstatus','marital_status').withColumnRenamed('nr_employmentstatus','employment_status')
    print('Date differences calculated\nVtu Dump converted to Vtu\nMonthly and weekly data consumption rate converted to gb')
    print('Daily consumption rate converted to mb\nColumns renamed')

    # transform device os version
    df_customers = df_customers.withColumn('version_number_length', length(df_customers['device_os_version']))
    df_customers = df_customers.withColumn('device_os_version', when(df_customers['version_number_length'] > 2, '0').otherwise(df_customers['device_os_version']))
    df_customers = df_customers.fillna('0', subset='device_os_version').withColumn('device_os_version', col('device_os_version').cast("integer"))\
    .drop('version_number_length')
    print('Device os versions extracted')
    
    # group and filter columns
    df_customers = udfs.create_others_value(df_customers, 'device_type', attr_dict, 'Others')
    df_customers = udfs.create_others_value(df_customers, 'line_type', attr_dict, 'Others')
    df_customers = udfs.create_others_value(df_customers, 'employment_status', attr_dict, 'Unemployed')
    df_customers = udfs.create_others_value(df_customers, 'marital_status', attr_dict, '')
    df_customers = udfs.create_others_value(df_customers, 'last_rchg_type', attr_dict, 'Others')
    print('All attribute values not in vendor features re-categorized\nCleaning completed')
    df_customers.cache();

    # save cleaned data
    with pd.ExcelWriter(f"{cleaned_folder_path}/tables_cleaned_{tbl_dt}.xlsx") as writer:
        df_vendors.to_excel(writer, sheet_name="Vendors", index=False)
        df_weights.to_excel(writer, sheet_name="Weights", index=False)
        for attr in attribute_names:
            attr_dict[attr] = attr_dict[attr].toPandas()
            attr_dict[attr].to_excel(writer, sheet_name=attr, index=False)
    writer.save()
    df_customers.write.mode('overwrite').parquet(f'{cleaned_folder_path}/customers_cleaned_{tbl_dt}')
    print('Cleaned data saved')
    
    spark.stop()

if __name__ == '__main__':
    fire.Fire(main)

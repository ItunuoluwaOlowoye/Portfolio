# import relevant packages
from pyspark.sql.functions import lower, col, when, concat, substring, to_date, lit
from pyspark.sql.types import DateType
import warnings
warnings.filterwarnings('ignore')

def proper_columns(dataframe_array:list):
    
    # For an array of DataFrames
    for df in dataframe_array:
        df = df.select([lower(col(column)).alias(column.replace(' ', '_')) for column in df.columns])

    return dataframe_array

# define function to write columns in snake case
def pd_proper_columns(dataframe_array:list):
    
    # for an array of dataframes
    for dataframe in dataframe_array:
        dataframe.columns = dataframe.columns.str.lower().str.replace(' ', '_')
    
    return dataframe_array

# convert date columns to date
def convert_date_columns(df, date_col_list:list):
    for column in date_col_list:
        # Replace 0 with null values
        df = df.withColumn(column, when(col(column) == 0, None).otherwise(col(column).cast("string")))

        # Extract year, month, and day
        df = df.withColumn('year', substring(col(column), 1, 4).cast("string"))
        df = df.withColumn('month', substring(col(column), 5, 2).cast("string"))
        df = df.withColumn('day', substring(col(column), 7, 2).cast("string"))

        # Fill missing month and day values with '01'
        df = df.withColumn('month', when(df.year.isNotNull() & df.month.isNull(), '01').otherwise(df.month))
        df = df.withColumn('day', when(df.year.isNotNull() & df.month.isNotNull() & df.day.isNull(), '01').otherwise(df.day))

        # Concatenate year, month, and day columns
        df = df.withColumn(column, concat(col('year'), col('month'), col('day')))

        # Convert to date type
        df = df.withColumn(column, to_date(col(column), 'yyyyMMdd').cast(DateType()))

        # Drop year, month, and day columns
        df = df.drop('year', 'month', 'day')

        print(f'{column} converted to datetime')
    return df

def create_others_value(df, column, attr_dict, others):
    #values_list = df.select(column).distinct().rdd.flatMap(lambda x: x).collect()
    #print(f'Initial list of values: \n {values_list}')

    valid_values = attr_dict[column].select(column).distinct().rdd.flatMap(lambda x: x).collect()
    valid_values.append('')

    df = df.withColumn(column, when(~col(column).isin(valid_values), lit(others)).otherwise(col(column)))

    #values_list = df.select(column).distinct().rdd.flatMap(lambda x: x).collect()
    #print(f'Final list of values: \n {values_list}')
    return df

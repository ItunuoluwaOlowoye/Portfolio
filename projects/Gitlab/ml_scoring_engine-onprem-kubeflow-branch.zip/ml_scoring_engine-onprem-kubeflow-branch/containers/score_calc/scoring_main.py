# import relevant packages
from parallel_pandas import ParallelPandas
import pandas as pd
from pyspark.sql.session import SparkSession
from pyspark.sql.functions import col, when, lit, explode, expr, first
from pyspark.sql.types import StringType, StructType, StructField
import fire
import warnings
warnings.filterwarnings('ignore')

def main(cleaned_folder_path:str,
         output_folder_path:str,
         tbl_dt:str):
    
    # configure the Spark session
    spark = SparkSession.builder \
    .master('local[*]') \
    .config("spark.driver.memory", "32g") \
    .appName('DigitalLending') \
    .getOrCreate()

    # initiate parallel pandas session
    ParallelPandas.initialize(n_cpu=-1, split_factor=4, disable_pr_bar=True)
    
    print('Loading data...')
    df_customers_clean = spark.read.parquet(f'{cleaned_folder_path}/customers_cleaned_{tbl_dt}/*.parquet')
    print('Customers loaded')
    
    excel_path = f"{cleaned_folder_path}/tables_cleaned_{tbl_dt}.xlsx"
    
    df_vendors_clean = pd.read_excel(excel_path, sheet_name='Vendors')
    df_weights_clean = pd.read_excel(excel_path, sheet_name='Weights')
    attr_dict = {}
    print('Lookup data loaded')
    
    # list the unique attributes in the weights table
    attribute_names = list(df_weights_clean['attribute'].unique())
    for attr in attribute_names:
        dataframe = pd.read_excel(excel_path, sheet_name=attr)

        # drop the size column if it exists
        if 'size' in dataframe.columns:
            dataframe = dataframe.drop('size')
        
        dataframe = spark.createDataFrame(dataframe)

        # if numeric attribute
        if 'min_'+attr in dataframe.columns and 'max_'+attr in dataframe.columns:

            # cast all numerical columns as integers
            numerical_columns = [column for column, dtype in dataframe.dtypes if dtype in ['int', 'bigint', 'float', 'double']]
            for column in numerical_columns:
                dataframe = dataframe.withColumn(column, col(column).cast("integer"))

            # generate a list of ranges
            dataframe = dataframe.withColumn('lists', expr(f"sequence(min_{attr}, max_{attr})"))
            
            # split the lists into individual values
            dataframe = dataframe.select('vendor_code', attr+'_score', explode('lists').alias(attr))
            
        # sort by attribute and remove duplicates, if any
        dataframe = dataframe.orderBy([attr,attr+'_score'])
        dataframe = dataframe.dropDuplicates(subset=['vendor_code',attr])
            
        attr_dict[attr] = dataframe
    print('Attributes dataframes created')
    
    df_vendors_clean = spark.createDataFrame(df_vendors_clean)
    df_weights_clean = spark.createDataFrame(df_weights_clean)
    
    # read customers, vendors, attributes and weights data
    # limit numeric values to 0 and 9999
    numerical_columns = [column for column, dtype in df_customers_clean.dtypes if dtype in ['int', 'bigint', 'float', 'double']]

    for column in numerical_columns:
        df_customers_clean = df_customers_clean.withColumn(
            column,
            when(col(column) > 9999, 9999)
            .when(col(column) < 0, 0)
            .otherwise(col(column))
            )
    print('Numeric fields set to minimum and maximum limits of 0 and 9999 respectively')

    # create list of columns in the dataframe
    df_columns = df_customers_clean.columns

    # Create a list of available vendors
    vendor_codes = df_vendors_clean.select('vendor_code').distinct().rdd.flatMap(lambda x: x).collect()

    # Create a DataFrame with the vendors available as new columns
    df_customers_clean = df_customers_clean.select(df_columns + [lit(x).alias(x) for x in vendor_codes])

     # create a temp SQL view
    df_customers_clean.createOrReplaceTempView('scoreCard')

    # remove the vendor code columns
    for code in vendor_codes:
        df_customers_clean = df_customers_clean.drop(code)

    # select columns ensuring that you do not select vendor code
    id_vars = [col for col in df_customers_clean.columns if col not in vendor_codes]

    # create empty vendor code and value columns
    df_customers_clean = df_customers_clean.withColumn('vendor_code',lit(None).cast('string')).withColumn('value',lit(None).cast('string'))

    # store the schema in a variable
    schema = df_customers_clean.schema

    # empty the dataframe, retaining its schema
    df_customers_clean = spark.createDataFrame([], schema)

    # fill the vendor code column with all the vendors in batches for each customer
    for code in vendor_codes:
        df = spark.sql("SELECT " + ", ".join(id_vars) + ", '" + code + "' AS vendor_code, " + code + " AS value FROM scoreCard" )
        df_customers_clean = df_customers_clean.unionAll(df)

    # drop intermediate columns
    df_customers_clean = df_customers_clean.drop('value')

    # drop the temp SQL view
    spark.catalog.dropTempView('scoreCard')

    # cache results
    df_customers_clean.cache();

    # select the attribute columns in the customer table that have attribute scores
    cust_attr_list = [column for column in df_customers_clean.columns if column in attr_dict.keys()]

    # select the attribute columns in the customer table that have attribute scores
    cust_attr_list = [column for column in df_customers_clean.columns if column in attr_dict.keys()]

     # join attribute scores with the score card
    for key in cust_attr_list:
        attr_dict[key].cache();
        df_customers_clean = df_customers_clean.join(attr_dict[key], on=[key,'vendor_code'], how='left')
        df_customers_clean = df_customers_clean.drop(key)
        print(f'{key} joined', end=',')

    # store results in cache
    df_customers_clean.cache();

    # store attribute weights in a separate df
    weight = df_weights_clean.drop('max_attr_value').withColumn('weight', col('weight').cast("float"))

    # re-engineer the weight column such that it becomes OLTP based on vendor code
    weight = weight.groupBy('vendor_code').pivot('attribute').agg(first('weight'))

     # isolate numeric columns and fill nulls with 0
    numeric_columns = weight.columns[1:]
    weight = weight.fillna(0, subset=numeric_columns)

    # sum up weights for each vendor
    weight = weight.select('*', expr('+'.join([col for col in numeric_columns])).alias('total_attr_weight'))

    # add the '_weight' suffix to the weight columns
    for column in numeric_columns:
        weight = weight.withColumnRenamed(column, column+'_weight')

    # join attribute weights with the score table
    weight = weight.cache();
    df_customers_clean = df_customers_clean.join(weight, on='vendor_code', how='left')

    # store max attribute score in a separate df
    max_score = df_weights_clean.drop('weight').withColumn('max_attr_value', col('max_attr_value').cast("float"))

    # re-engineer the table to be OLTP based on vendor code
    max_score = max_score.groupBy('vendor_code').pivot('attribute').agg(first('max_attr_value'))

    # isolate numeric columns
    numeric_columns = max_score.columns[1:]
    max_score = max_score.fillna(0, subset=numeric_columns)

    # add the _max_score suffix
    for column in numeric_columns:
        max_score = max_score.withColumnRenamed(column, column+'_max_score')

    # join the max score table to the score table
    max_score = max_score.cache();
    df_customers_clean = df_customers_clean.join(max_score, on='vendor_code', how='left')

    # unpersist cached dfs
    weight.unpersist();
    max_score.unpersist();
    df_weights_clean.unpersist();

     # calculate WAS for each attribute
    for attr in cust_attr_list:
        df_customers_clean = df_customers_clean.withColumn('WAS_'+attr, 
                            (col(attr+'_score')/col(attr+'_max_score')) * (col(attr+'_weight')/col('total_attr_weight'))
                            )

    # select required columns
    relevant_cols = ['msisdn','vendor_code'] + [col for col in df_customers_clean.columns if 'WAS_' in col]

    # select required columns in the dataframe
    df_customers_clean = df_customers_clean.select(relevant_cols)

    # fill nulls in numeric columns with 0
    numerical_columns = [column for column, dtype in df_customers_clean.dtypes if dtype in ['int', 'bigint', 'float', 'double']]
    df_customers_clean = df_customers_clean.fillna(0, subset=numerical_columns)

    # sum up all numeric columns (WAS) to calculate overall credit score
    df_customers_clean = df_customers_clean.select('*', expr('+'.join([col for col in df_customers_clean.columns[2:]])).alias('WAS_overall'))

    # save data
    df_customers_clean.write.mode('overwrite').parquet(f'{output_folder_path}/lending_scores_{tbl_dt}')
    
    spark.stop()
    print('Model complete')

if __name__ == '__main__':
    fire.Fire(main)

# import modules
import kfp
import kfp.dsl as dsl
import kfp.compiler as compiler
from kubernetes import client
import os

# define env variables
COMPONENT_URL_SEARCH_PREFIX = os.getenv('COMPONENT_URL_SEARCH_PREFIX')
RUNTIME_VERSION = os.getenv('RUNTIME_VERSION')
PYTHON_VERSION = os.getenv('PYTHON_VERSION')
ENDPOINT = os.environ['ON_PREM_ENDPOINT']
os.environ['JAVA_HOME'] = '/mnt/beegfs_adam/jdk-9/jdk-9/'
PROJECT_ID = os.environ['ADAM_MANCO_PROJECT_ID']
TABLE_DATE = os.environ['TABLE_DATE']

if TABLE_DATE == 'previous month':
  current_date = datetime.date.today()

  first_day_of_current_month = current_date.replace(day=1)
  last_day_of_previous_month = first_day_of_current_month - datetime.timedelta(days=1)

  previous_month_year = last_day_of_previous_month.year
  previous_month = last_day_of_previous_month.month
  
  _, last_day = calendar.monthrange(previous_month_year, previous_month)
  TABLE_DATE = str(previous_month_year).zfill(4) + str(previous_month).zfill(2) + str(last_day).zfill(2)

else:
  TABLE_DATE = os.environ['TABLE_DATE']

# define pipeline components

#1. Data cleaning
def cleaning_op(raw_folder_path:str, cleaned_folder_path:str, tbl_dt:str):
    return dsl.ContainerOp(
        name='Customer data cleaning',
        image='eu.gcr.io/lending-internale6ef9722/digital_lending/cleaning:latest',
        arguments = [
            '--raw_folder_path', raw_folder_path, 
            '--cleaned_folder_path', cleaned_folder_path,
            '--tbl_dt', tbl_dt
        ],
        command = ["python","-m", "cleaning_main"]
    ).add_pvolumes({"/mnt/beegfs_adam": dsl.PipelineVolume(pvc="mntbeegfsadamkfp")})

#2. Scoring
def scoring_op(cleaned_folder_path:str, output_folder_path:str, tbl_dt:str):
    return dsl.ContainerOp(
        name='Weighted Average Credit Scores',
        image='eu.gcr.io/lending-internale6ef9722/digital_lending/onprem_scoring:latest',
        arguments = [
            '--cleaned_folder_path', cleaned_folder_path,
            '--output_folder_path', output_folder_path,
            '--tbl_dt', tbl_dt
        ],
        command = ["python","-m", "scoring_main"]
    ).add_pvolumes({"/mnt/beegfs_adam": dsl.PipelineVolume(pvc="mntbeegfsadamkfp")})

@kfp.dsl.pipeline(
    name='MTN NG Digital Lending Model Pipeline',
    description='Pipeline for calculating credit scores'
    )

def digital_lending_model_onprem(
    raw_folder_path:str = '/mnt/beegfs_adam/scoring_input_data/digital_lending/raw_data',
    cleaned_folder_path:str = '/mnt/beegfs_adam/scoring_output_data/digital_lending',
    output_folder_path:str = '/mnt/beegfs_adam/scoring_output_data/digital_lending',
    tbl_dt:str=TABLE_DATE
):
    
    _cleaning_op = cleaning_op(raw_folder_path, output_folder_path, tbl_dt)
    _cleaning_op.execution_options.caching_strategy.max_cache_staleness = "P0D"
    
    _scoring_op = scoring_op(cleaned_folder_path, output_folder_path, tbl_dt).after(_cleaning_op)
    _scoring_op.execution_options.caching_strategy.max_cache_staleness = "P0D"

import kfp
import json
import fire 
from datetime import datetime
from pytz import timezone

def get_pipeline_id(kfp_client, pipeline_name):
    
    pipelines = kfp_client.pipelines.list_pipelines()
    l=len(pipelines.pipelines)
    
    for i in range(l):
        name = pipelines.pipelines[i].name
        #print(name)
        idd=pipelines.pipelines[i].id
        #print(idd)
        if(name == pipeline_name):
            return idd
    print("Pipeline name not matching. Please pass pipeline name")
    # return False
    

def get_experiment_id(kfp_client, experiment_name=None):
    
    try:
        experiment = kfp_client.create_experiment(experiment_name)
        return experiment.id
    except:
        experiment = kfp_client.create_experiment('Default')
        return experiment.id

def upload_pipelne(kfp_client,pipeline_file_name,pipeline_name):
    
    pipeline_id = get_pipeline_id(kfp_client, pipeline_name)
    
    if(pipeline_id):
        print(f"Pipeline id is {pipeline_id}")
        #get default version
        version_name=kfp_client.pipelines.list_pipeline_versions(resource_key_id=pipeline_id).versions[-1].name
        print(f"Default pipeline version is {version_name}")
        #update version name
        try:
            version_name=version_name.rsplit('_', 1)[0]+'_'+str(int(version_name.rsplit('_', 1)[1])+1)
        except:
            version_name=version_name+'_1'
        #upload pipeline with new virsion
        pipeline = kfp_client.pipeline_uploads.upload_pipeline_version(uploadfile = pipeline_file_name,name=version_name,pipelineid=pipeline_id)
        print(f"Pipeline with version: {version_name} have been uploaded.")
    else:
        pipeline = kfp_client.pipeline_uploads.upload_pipeline(uploadfile = pipeline_file_name,name = pipeline_name)
        print(f"New pipeline with {pipeline_name} have been uploaded.")
    return pipeline_id

def load_to_pipeline_to_kfp(kfp_client, pipeline_file_name, pipeline_name):
    
    #test if the pipeline exists
    pipeline_id = get_pipeline_id(kfp_client, pipeline_name)
    
    #if it exists, upload a new version
    if pipeline_id is not None:
        #get default version
        version_name=kfp_client.pipelines.list_pipeline_versions(resource_key_id=pipeline_id).versions[-1].name
        #update version name
        try: #it was the first version so there was no number on the version name
            version_name=version_name.rsplit('_', 1)[0]+'_'+str(int(version_name.rsplit('_', 1)[1])+1)     
        except:
            version_name=str(version_name)+'_'+str(0)
        #upload pipeline with new version
        pipeline_id = get_pipeline_id(kfp_client, pipeline_name)
        pipeline = kfp_client.pipeline_uploads.upload_pipeline_version(pipeline_file_name, name=version_name, pipelineid=pipeline_id)
    #the pipeline does not exist yet so we create it 
    else:
        pipeline = kfp_client.pipeline_uploads.upload_pipeline(uploadfile=pipeline_file_name, name=pipeline_name)
        pipeline_id = get_pipeline_id(kfp_client, pipeline_name)
    return pipeline_id


def main(ENDPOINT,pipeline_file_name,pipeline_name,experiment_name=None):

    host=ENDPOINT
    kfp_client = kfp.Client(host)
    
    # pipeline_id = upload_pipelne(kfp_client,pipeline_file_name,pipeline_name)
    
    ###
    pipeline_id = load_to_pipeline_to_kfp(kfp_client,pipeline_file_name,pipeline_name)
    run_id = datetime.now(timezone("Africa/Johannesburg")).strftime("%Y%m%d%H%M%S")
    run_name = str(pipeline_name)+'_'+ str(run_id)

    if experiment_name is not None:
        experiment_id = get_experiment_id(kfp_client, experiment_name)
    else:
        experiment_id = get_experiment_id(kfp_client)
        
    params = {
        
    }
    print("Creating run with params:")
    print(params)
    run = kfp_client.run_pipeline(experiment_id, job_name=run_name, pipeline_id=pipeline_id, params=params)


if __name__ == '__main__':
    fire.Fire(main)

from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext
 
conf = SparkConf().setAll([])
spark = (SparkSession.builder.config(conf=conf).appName("ADAM Production").enableHiveSupport().getOrCreate())
sqlContext = SQLContext(spark)

customer_data = sqlContext.sql("select * from i_gcp.adam_digital_lending where tbl_dt=_TABLE_DATE_ limit 100")
customer_data.write.mode("overwrite").parquet("file:///mnt/beegfs_adam/gcp01/_PROJECT_FOLDER_NAME_/raw_data/customers")

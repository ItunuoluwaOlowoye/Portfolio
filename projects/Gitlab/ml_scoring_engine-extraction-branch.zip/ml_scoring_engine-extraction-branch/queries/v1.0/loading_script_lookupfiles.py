#intial imports
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, SQLContext
from pyspark.sql.functions import desc

#Set spark context
conf = SparkConf().setAll([])
spark = (SparkSession.builder.config(conf=conf).appName("MTN ADAM NG Digital Lending Production").enableHiveSupport().getOrCreate())
sqlContext = SQLContext(spark)

query = """
select * from i_gcp.digitallending__LOOKUP_TABLE_NAME_
"""

df = sqlContext.sql(query)
df = df.orderBy(desc('datekey')).dropDuplicates()

df.write.mode("overwrite").csv("file:///mnt/beegfs_adam/gcp01/_PROJECT_FOLDER_NAME_/raw_data/lookup/_LOOKUP_FILE_NAME_", header=True)

import os
import datetime
import calendar

# Read the environment variables
pipeline_id = os.environ['CI_PIPELINE_ID']
project_folder_id = os.environ['PROJECT_FOLDER_NAME']

if os.environ['TABLE_DATE'] == 'previous month':
  current_date = datetime.date.today()

  first_day_of_current_month = current_date.replace(day=1)
  last_day_of_previous_month = first_day_of_current_month - datetime.timedelta(days=1)

  previous_month_year = last_day_of_previous_month.year
  previous_month = last_day_of_previous_month.month
  
  _, last_day = calendar.monthrange(previous_month_year, previous_month)
  table_date = str(previous_month_year).zfill(4) + str(previous_month).zfill(2) + str(last_day).zfill(2)

else:
  table_date = os.environ['TABLE_DATE']

data_extraction_script = os.environ['DATA_EXTRACTION_SCRIPT']
script_version = os.environ['SCRIPT_VERSION']
table_name = os.environ['LOOKUP_TABLE_NAME']
file_name = os.environ['LOOKUP_FILE_NAME']

#Read loading script
base_dir = "".join(os.path.dirname(__file__).split("/")[:-1])
__location__ = os.path.dirname(__file__) + '/../queries/' + script_version + '/loading_script_' + data_extraction_script + '.py'

with open(__location__, 'r') as file :
  filedata = file.read()

# Replace the target string
filedata = filedata.replace('_PROJECT_FOLDER_NAME_', project_folder_id)
filedata = filedata.replace('_TABLE_DATE_', table_date)
filedata = filedata.replace('_LOOKUP_TABLE_NAME_', table_name)
filedata = filedata.replace('_LOOKUP_FILE_NAME_', file_name)


# Write the file out again
base_location = "/mnt/beegfs_adam/temp/"
base_file_name = "query_script"
unique_string = pipeline_id
file_extension = ".py"
output_path = base_location + base_file_name + unique_string + file_extension
print(output_path)
with open(output_path, 'w+') as file:
  file.write(filedata)


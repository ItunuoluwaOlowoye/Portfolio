# import relevant packages
from parallel_pandas import ParallelPandas
from google.cloud import bigquery_datatransfer_v1 as datatransfer
from google.protobuf import struct_pb2
import pandas as pd
import numpy as np
import pandas_gbq
import time
import fire
import udfs
import warnings
warnings.filterwarnings('ignore')

def main(cleaned_folder_path, tbl_dt, project_id, cust_dataset_id, attr_dataset_id, weight_dataset_id, cust_table_id, file_format, config_name, timeout):
    
    # initiate parallel pandas session
    ParallelPandas.initialize(n_cpu=-1, split_factor=4, disable_pr_bar=True)
    
    excel_path = f"{cleaned_folder_path}/tables_cleaned_{tbl_dt}.xlsx"
    
    df_weights_clean = pd.read_excel(excel_path, sheet_name='Weights')
    print('Lookup data loaded')
    
    # list the unique attributes in the weights table
    attribute_names = list(df_weights_clean['attribute'].unique())
    for attr in attribute_names:
        dataframe = pd.read_excel(excel_path, sheet_name=attr)
        # if numeric attribute
        if f'min_{attr}' in dataframe.columns and f'max_{attr}' in dataframe.columns:

            for i in dataframe.index:
                ranges = list(np.arange(dataframe.loc[i,'min_'+attr], dataframe.loc[i,'max_'+attr]+1, 1))
                dataframe.loc[i,'lists'] = ','.join([str(elem) for elem in ranges])
            dataframe = dataframe.assign(values = dataframe.lists.str.split(','))
            dataframe.drop(['min_'+attr, 'max_'+attr, 'lists'],axis=1,inplace=True)
            dataframe = dataframe.explode('values').reset_index(drop=True)
            dataframe.drop_duplicates(['vendor_code','values'],keep='first',inplace=True)
            dataframe['values'] = dataframe['values'].astype(float).astype(int)
            dataframe.rename(columns={'values':f'{attr}'}, inplace=True)
            
        # Sort by attribute and remove duplicates, if any
        dataframe = dataframe.sort_values(by=['vendor_code', attr, f'{attr}_score'])
        dataframe = dataframe.drop_duplicates(subset=['vendor_code', attr])
        
        pandas_gbq.to_gbq(dataframe=dataframe, destination_table=f'{attr_dataset_id}.{attr}', project_id=project_id, chunksize=None, 
                           api_method='load_csv', if_exists='replace', progress_bar=False)

    print('Attributes BQ tables created')
    
    weight = df_weights_clean.drop('max_attr_value',axis=1).pivot_table(index=['vendor_code'], columns='attribute', values='weight')
    weight.columns = weight.columns + '_weight'
    weight['total_attr_weight'] = weight.sum(axis=1)
    weight.reset_index(inplace=True)
    pandas_gbq.to_gbq(dataframe=weight, destination_table=f'{weight_dataset_id}.weights', project_id=project_id, chunksize=None,
                      api_method='load_csv', if_exists='replace', progress_bar=False)
    print('Weights BQ table created')
    
    max_score = df_weights_clean.drop('weight',axis=1).pivot_table(index=['vendor_code'], columns='attribute',values='max_attr_value')
    max_score.columns = max_score.columns + '_max_score'
    max_score.reset_index(inplace=True)
    pandas_gbq.to_gbq(dataframe=max_score, destination_table=f'{weight_dataset_id}.max_attr_score', project_id=project_id, chunksize=None,
                      api_method='load_csv', if_exists='replace', progress_bar=False)
    print('Max attribute score BQ table created')
    
    print('Transferring customer data from GCS to BQ')
    source_uri =  f'{cleaned_folder_path}/customers_cleaned_{tbl_dt}/*.parquet'

    params = {
        "destination_table_name_template": struct_pb2.Value(string_value=cust_table_id),
        "data_path_template": struct_pb2.Value(string_value=source_uri),
        "write_disposition": struct_pb2.Value(string_value="MIRROR"),
        "file_format": struct_pb2.Value(string_value=file_format)
    }
    
    transfer_config = datatransfer.TransferConfig(
        destination_dataset_id=cust_dataset_id,
        display_name="Transferring cleaned customer data from GCS to BigQuery",
        data_source_id="google_cloud_storage",
        params=struct_pb2.Struct(fields=params),
        schedule=None,
        next_run_time=None
    )
    
    udfs.run_cloud_storage_transfer(project_id, transfer_config, config_name)
    
    time.sleep(timeout) # sleep for 5 minutes to complete transfer job

if __name__ == '__main__':
    fire.Fire(main)

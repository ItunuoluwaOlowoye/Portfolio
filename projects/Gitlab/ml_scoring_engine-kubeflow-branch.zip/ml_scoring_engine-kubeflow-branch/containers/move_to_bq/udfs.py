# import relevant packages
import datetime
import warnings
from google.cloud import bigquery_datatransfer_v1 as datatransfer
warnings.filterwarnings('ignore')

def run_cloud_storage_transfer(project_id, transfer_config, config_name):
    
    client = datatransfer.DataTransferServiceClient()
    parent = f"projects/{project_id}"
    request = datatransfer.CreateTransferConfigRequest(
        parent=parent,
        transfer_config=transfer_config
    )
    
    try:
        #config = client.create_transfer_config(request)
        #print(f"Cloud storage transfer created successfully: {config.name}")
        
        # Initialize request argument(s)
        request = datatransfer.StartManualTransferRunsRequest(parent=config_name, requested_run_time=datetime.datetime.now())

        # Make the request
        response = client.start_manual_transfer_runs(request=request)
        for run in response.runs:
            run_name = run.name
            print(f'Transfer run started successfully: {run_name}')          
            
    except Exception as ex:
        print(f"Cloud storage transfer was not run. {ex}")
# import modules
import kfp
import kfp.dsl as dsl
import kfp.compiler as compiler
from kubernetes import client
import os
import time
import datetime
import calendar

# define env variables
COMPONENT_URL_SEARCH_PREFIX = os.getenv('COMPONENT_URL_SEARCH_PREFIX')
RUNTIME_VERSION = os.getenv('RUNTIME_VERSION')
PYTHON_VERSION = os.getenv('PYTHON_VERSION')
ENDPOINT = 'https://bcbeff8aaadd26e-dot-europe-west1.pipelines.googleusercontent.com'
TABLE_DATE = os.environ['TABLE_DATE']

if TABLE_DATE == 'previous month':
  current_date = datetime.date.today()

  first_day_of_current_month = current_date.replace(day=1)
  last_day_of_previous_month = first_day_of_current_month - datetime.timedelta(days=1)

  previous_month_year = last_day_of_previous_month.year
  previous_month = last_day_of_previous_month.month
  
  _, last_day = calendar.monthrange(previous_month_year, previous_month)
  TABLE_DATE = str(previous_month_year).zfill(4) + str(previous_month).zfill(2) + str(last_day).zfill(2)

else:
  TABLE_DATE = os.environ['TABLE_DATE']

# define pipeline components

#1. Data cleaning
def cleaning_op(raw_folder_path:str, cleaned_folder_path:str, tbl_dt:str):
    return dsl.ContainerOp(
        name='Customer data cleaning',
        image='eu.gcr.io/lending-internale6ef9722/digital_lending/cleaning:latest',
        arguments = [
            '--raw_folder_path', raw_folder_path, 
            '--cleaned_folder_path', cleaned_folder_path,
            '--tbl_dt', tbl_dt
        ],
        command = ["python","-m", "cleaning_main"]
    )

#2. Data migration to BigQuery
def migration_op(cleaned_folder_path, tbl_dt, project_id, cust_dataset_id, attr_dataset_id, weight_dataset_id, cust_table_id, file_format, config_name, timeout):
    return dsl.ContainerOp(
        name='Migrate data from GCS to BigQuery',
        image='eu.gcr.io/lending-internale6ef9722/digital_lending/move_to_bq:latest',
        arguments=[
            '--cleaned_folder_path', cleaned_folder_path,
            '--tbl_dt', tbl_dt,
            '--project_id', project_id,
            '--cust_dataset_id', cust_dataset_id,
            '--attr_dataset_id', attr_dataset_id,
            '--weight_dataset_id', weight_dataset_id,
            '--cust_table_id', cust_table_id,
            '--file_format', file_format,
            '--config_name', config_name,
            '--timeout', timeout
        ],
        command = ["python", "-m", "move_to_bq_main"]
    )

#2. Scoring
def scoring_op(cleaned_folder_path:str, bucket_name:str, destination_blob_name:str, timeout:int, tbl_dt:str):
    return dsl.ContainerOp(
        name='Weighted Average Credit Scores',
        image='eu.gcr.io/lending-internale6ef9722/digital_lending/gcp_scoring:latest',
        arguments = [
            '--cleaned_folder_path', cleaned_folder_path,
            '--bucket_name', bucket_name,
            '--destination_blob_name', destination_blob_name,
            '--timeout', timeout,
            '--tbl_dt', tbl_dt
        ],
        command = ["python","-m", "scoring_main"]
    )

# Create pipeline
@kfp.dsl.pipeline(
    name='MTN NG Digital Lending Model GCP Pipeline',
    description='GCP Pipeline for calculating credit scores'
    )

def digital_lending_model_gcp(
    raw_folder_path:str = 'gs://mtn-adam-nigeria-lending-eva-data-storage-ec377f30/gcp01/adam_digital_lending/raw_data',
    cleaned_folder_path:str = 'gs://mtn-adam-nigeria-lending-eva-data-storage-ec377f30/gcp01/adam_digital_lending/cleaned_data',
    tbl_dt:str=TABLE_DATE,
    project_id:str = 'lending-internale6ef9722',
    cust_dataset_id:str = 'customers',
    attr_dataset_id:str = 'attributes',
    weight_dataset_id:str = 'weights_and_max_attr_score',
    cust_table_id:str = "customers",
    file_format:str = "PARQUET",
    config_name:str = 'projects/508158342745/locations/us/transferConfigs/65396579-0000-2215-8cda-883d24f9dfec',
    timeout:int = 600,
    bucket_name:str = 'mtn-adam-nigeria-lending-eva-data-storage-ec377f30',
    destination_blob_name:str = 'gcp01/adam_digital_lending/output_data'
):
    
    memory = '115Gi'
    CPU = '15'
    ephemeral = '40Gi'
    
    _cleaning_op = cleaning_op(raw_folder_path, cleaned_folder_path, tbl_dt)
    _cleaning_op.container.set_ephemeral_storage_limit(ephemeral)
    _cleaning_op.container.set_memory_request(memory)
    _cleaning_op.container.set_cpu_request(CPU)
    _cleaning_op.container.set_memory_limit(memory)
    _cleaning_op.container.set_cpu_limit(CPU)
    _cleaning_op.execution_options.caching_strategy.max_cache_staleness = "P0D"
    
    _migration_op = migration_op(cleaned_folder_path, tbl_dt, project_id, cust_dataset_id, attr_dataset_id,
                                 weight_dataset_id, cust_table_id, file_format, config_name, timeout).after(_cleaning_op)
    _migration_op.container.set_ephemeral_storage_limit(ephemeral)
    _migration_op.container.set_memory_request(memory)
    _migration_op.container.set_cpu_request(CPU)
    _migration_op.container.set_memory_limit(memory)
    _migration_op.container.set_cpu_limit(CPU)
    _migration_op.execution_options.caching_strategy.max_cache_staleness = "P0D"
    
    _scoring_op = scoring_op(cleaned_folder_path, bucket_name, destination_blob_name, timeout, tbl_dt).after(_migration_op)
    _scoring_op.container.set_ephemeral_storage_limit(ephemeral)
    _scoring_op.container.set_memory_request(memory)
    _scoring_op.container.set_cpu_request(CPU)
    _scoring_op.container.set_memory_limit(memory)
    _scoring_op.container.set_cpu_limit(CPU)
    _scoring_op.execution_options.caching_strategy.max_cache_staleness = "P0D"

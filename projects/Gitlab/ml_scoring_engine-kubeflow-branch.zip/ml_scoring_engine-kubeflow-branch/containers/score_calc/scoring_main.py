import gcsfs
from google.cloud import bigquery
from google.cloud import storage
import fire
import time
import pandas as pd
from pyspark.sql.session import SparkSession

project_id = 'lending-internale6ef9722'
dataset_id = 'customers'
table_id = 'scores'

def main(cleaned_folder_path:str, bucket_name:str, destination_blob_name:str, timeout:int, tbl_dt:str):
    
    # create a BQ and storage client
    bq_client = bigquery.Client()
    storage_client = storage.Client()
    
    # create queries for creating the score table, joining attributes, max scores, and weights
    min_max_limit_query = f'''
        WITH numeric_columns AS (
          SELECT column_name
          FROM `customers.INFORMATION_SCHEMA.COLUMNS`
          WHERE table_name = 'customers' and column_name != 'tbl_dt' 
            AND data_type IN ('INT64', 'FLOAT64')
        )

        SELECT
          STRING_AGG(
            CONCAT(
              'CASE WHEN ', column_name, ' > 9999 THEN 9999 WHEN ', column_name, ' < 0 THEN 0 ELSE ', column_name, ' END AS ', column_name
            ),
            ' , '


          ) AS min_max_limit_query
        FROM numeric_columns;
        '''
    
    min_max_limit_query = pd.read_gbq(min_max_limit_query, project_id=project_id).iloc[0,0]
    
    # extract non-numeric column headers
    non_numeric_columns_query = '''
        SELECT column_name FROM customers.INFORMATION_SCHEMA.COLUMNS WHERE table_name = "customers"
        AND column_name != 'tbl_dt' AND data_type NOT IN ('INT64', 'FLOAT64')'''
    non_numeric_columns = pd.read_gbq(query=non_numeric_columns_query, project_id=project_id).iloc[:,0].to_list()
    non_numeric_columns = ', '.join(non_numeric_columns)
    
    # create table with normalized cdr fields
    table_creation_query = f'''create or replace table customers.scores as(
        SELECT {non_numeric_columns}, {min_max_limit_query}, tbl_dt FROM customers.customers)'''
    
    score_creation_query = '''create or replace table customers.scores as (
    WITH RECURSIVE UnionAllRecursive AS (
          SELECT 1 AS iteration, vendor_code
          FROM (SELECT distinct vendor_code
          FROM weights_and_max_attr_score.weights)
          UNION ALL
          SELECT u.iteration + 1, SPLIT(u.vendor_code, ',')[OFFSET(u.iteration)] AS vendor_code
          FROM UnionAllRecursive u
          JOIN (SELECT distinct vendor_code
          FROM weights_and_max_attr_score.weights) v
          ON u.iteration + 1 <= ARRAY_LENGTH(SPLIT(v.vendor_code, ','))
        )
    SELECT c.*, u.vendor_code
    FROM customers.scores c
    JOIN UnionAllRecursive u
    ON TRUE
    )'''
    
    join_attributes_query = '''CALL procedures.joinAttributes(1);'''
    
    join_weights_query = '''CALL procedures.joinWeights(1);'''
    
    # initialize the score table
    query_job = bq_client.query('drop table if exists customers.scores')
    query_job.result()
    query_job = bq_client.query(table_creation_query)
    query_job.result()
    query_job = bq_client.query(score_creation_query)
    query_job.result()
    print('Score table created')
    
    # join attributes
    query_job = bq_client.query(join_attributes_query)
    query_job.result()
    print('Attributes joined')
    
    # join weights and max scores
    query_job = bq_client.query(join_weights_query)
    query_job.result()
    print('Weights and max attribute scores joined')
    
    excel_path = f"{cleaned_folder_path}/tables_cleaned_{tbl_dt}.xlsx"
    
    df_weights_clean = pd.read_excel(excel_path, sheet_name='Weights')
    print('Weights data loaded')
    
    # extract column headers
    data_columns_query = '''SELECT column_name FROM customers.INFORMATION_SCHEMA.COLUMNS WHERE table_name = "customers"'''
    data_columns = pd.read_gbq(query=data_columns_query, project_id=project_id).iloc[:,0].to_list()
    
    # list the unique attributes in the weights table
    attribute_names = list(df_weights_clean['attribute'].unique())
    
    # select the attribute columns in the customer table that have attribute scores
    selected_columns = [column for column in data_columns if column in attribute_names]
    calculated_columns = ['WAS_' + col for col in selected_columns]
    cols_to_save = ['msisdn', 'vendor_code'] + calculated_columns + ['tbl_dt']
    
    # calculate WAS
    for attr in selected_columns:
        score_query = f'''CREATE OR REPLACE TABLE {dataset_id}.{table_id} AS
            (SELECT *, IFNULL({attr}_score / {attr}_max_score, 0) * IFNULL({attr}_weight / total_attr_weight, 0) AS WAS_{attr}
            FROM {dataset_id}.{table_id});'''
        query_job = bq_client.query(score_query)
        query_job.result()
    
    cols_to_save = ', '.join(cols_to_save)
    cols_to_save_query = f'''CREATE OR REPLACE TABLE {dataset_id}.{table_id} AS (
        SELECT {cols_to_save} FROM {dataset_id}.{table_id})'''    
    query_job = bq_client.query(cols_to_save_query)
    query_job.result()
    print('Each WAS calculated')
    
    # calculate WAS overall
    calculated_columns = ' + '.join(calculated_columns)
    final_query = f'''CREATE OR REPLACE TABLE {dataset_id}.{table_id} AS (
        SELECT *, {calculated_columns} AS WAS_overall FROM {dataset_id}.{table_id})'''
    query_job = bq_client.query(final_query)
    query_job.result()
    print('Overall WAS calculated')
    
    # save BQ results to GCS
    table_ref = bq_client.dataset(dataset_id).table(table_id)
    bucket = storage_client.get_bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    job_config = bigquery.job.ExtractJobConfig()
    job_config.destination_format = 'PARQUET'
    bq_destination = f'gs://{bucket_name}/{destination_blob_name}/intermediate_scores_{tbl_dt}/*.parquet'
    
    extract_job = bq_client.extract_table(table_ref, destination_uris=bq_destination, job_config=job_config)
    extract_job.result()
    print(f'Data saved to GCS: {bq_destination}')
    
    time.sleep(timeout)
    spark = SparkSession.builder \
    .master('local[*]') \
    .config("spark.driver.memory", "32g") \
    .appName('DigitalLending') \
    .getOrCreate()
    df_scores = spark.read.parquet(f'{bq_destination}')
    df_scores.write.mode('overwrite').parquet(f'gs://{bucket_name}/{destination_blob_name}/lending_scores_{tbl_dt}/')
    spark.stop()
    blobs = bucket.list_blobs(prefix=f'{destination_blob_name}/intermediate_scores_{tbl_dt}/')
    for blob in blobs: blob.delete()
    print('Model complete')

if __name__ == '__main__':
    fire.Fire(main)


Set of instructions to be able to use the Digital Lending Usecase

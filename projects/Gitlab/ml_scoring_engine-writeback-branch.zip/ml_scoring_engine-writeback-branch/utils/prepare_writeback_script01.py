import os

# Read user inputs from command-line arguments
parquet_file_path = os.environ['PARQUET_FILE_PATH']
hive_table_name = os.environ['HIVE_TABLE_NAME']
update_mode = os.environ['UPDATE_MODE']
pipeline_id = os.environ['CI_PIPELINE_ID']
template_number= "01"


__location__ = os.path.dirname(__file__) + '/../templates/writeback_query01.py'

with open(__location__, 'r') as file :
  filedata = file.read()

# Replace the target string  
filedata = filedata.replace('_PARQUET_FILE_PATH_', parquet_file_path )
filedata = filedata.replace('_HIVE_TABLE_NAME_', hive_table_name )
filedata = filedata.replace('_PIPELINE_ID_TEMPLATE_INPUT_', pipeline_id)
filedata = filedata.replace('_UPDATE_MODE_', update_mode)

# Write the file out again
base_location = "/mnt/beegfs_adam/temp/"
base_file_name = "query_script"
unique_string = pipeline_id
file_extension = ".py"
output_path = base_location + base_file_name + unique_string + file_extension
print(output_path)
with open(output_path, 'w+') as file:
  file.write(filedata)

import sys
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext

# Create a SparkSession
conf = SparkConf().setAll([])
spark = (SparkSession.builder.config(conf=conf).appName("ADAM Production Update Hive table with Parquet data").enableHiveSupport().getOrCreate())

# Read the updated Parquet file into a DataFrame
df = spark.read.parquet("_PARQUET_FILE_PATH_")

if spark.sql("SHOW TABLES LIKE '{}'".format("_HIVE_TABLE_NAME_")).count() == 1:
    # Table exists, update it based on the update mode
    if '_UPDATE_MODE_' == "append":
        df.write.mode("append").insertInto("_HIVE_TABLE_NAME_")
    else:
        raise Exception("Table already exists and update mode is set to fail")
else:
    # Table does not exist, create it with the DataFrame schema
    df.write.mode("overwrite").saveAsTable("_HIVE_TABLE_NAME_")

# Stop the SparkSession
spark.stop()

from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext
 
conf = SparkConf().setAll([])
spark = (SparkSession.builder.config(conf=conf).appName("ADAM Production").enableHiveSupport().getOrCreate())
sqlContext = SQLContext(spark)
df = sqlContext.sql("_SQL_QUERY_TEMPLATE_INPUT_")
# df.write.mode("overwrite")._OUTPUT_DATA_TYPE_INPUT_("file:///mnt/beegfs_adam/gcp01/_PIPELINE_ID_TEMPLATE_INPUT_")
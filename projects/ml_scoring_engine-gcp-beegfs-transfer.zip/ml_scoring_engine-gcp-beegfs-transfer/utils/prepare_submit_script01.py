import os

# Read the environment variable
sql_query = os.environ['SQL_QUERY']
pipeline_id = os.environ['CI_PIPELINE_ID']
# output_data_type = os.environ['OUTPUT_DATA_TYPE']
template_number= "01"


__location__ = os.path.dirname(__file__) + '/../templates/query_template01.py'

with open(__location__, 'r') as file :
  filedata = file.read()

# Replace the target string
filedata = filedata.replace('_SQL_QUERY_TEMPLATE_INPUT_', sql_query )
filedata = filedata.replace('_PIPELINE_ID_TEMPLATE_INPUT_', pipeline_id)
# filedata = filedata.replace('_OUTPUT_DATA_TYPE_INPUT_', output_data_type)

# Write the file out again
base_location = "/mnt/beegfs_adam/temp/"
base_file_name = "query_script"
unique_string = pipeline_id
file_extension = ".py"
output_path = base_location + base_file_name + unique_string + file_extension
print(output_path)
with open(output_path, 'w+') as file:
  file.write(filedata)
